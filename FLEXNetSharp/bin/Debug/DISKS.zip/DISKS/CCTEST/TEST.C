#include <stdio.h>

char *global_c = "this is global c";

long global_d;

int global_a;
int global_b = 0x55;

int main (argc, argv)
int argc;
char **argv;
{
    int local_a;
    int local_b = 0x56;

    printf("Hello World");
    printf("GoodBye");
}


       